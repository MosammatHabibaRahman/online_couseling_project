$(document).ready(function () {
    $('.accept').click(function (){
        var id=$(this).val();
    });
    $('.reject').click(function (){
        var id=$(this).val();
    });
});
